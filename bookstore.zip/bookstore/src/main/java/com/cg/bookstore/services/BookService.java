package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;

public interface BookService {
	Book acceptBookDetails(Book book);
	Book getBookDetails(int bookId)throws BookDetailsNotFoundException;
	List<Book> getAllBookDetails();
	
}
