package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.dao.BookDao;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;
@Component("bookService")
public class BookServiceImpl implements BookService {
@Autowired
	BookDao bookDao; 
	@Override
	public Book acceptBookDetails(Book book) {
		book=bookDao.save(book);
		return book;
	}

	@Override
	public Book getBookDetails(int bookId) throws BookDetailsNotFoundException {
		
		return bookDao.findById(bookId).orElseThrow(()->new BookDetailsNotFoundException("Sorry! Book Not Found"));
	}

	@Override
	public List<Book> getAllBookDetails() {
		return bookDao.findAll();
	}

}
